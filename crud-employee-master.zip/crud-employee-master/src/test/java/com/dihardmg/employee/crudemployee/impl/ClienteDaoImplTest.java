package com.dihardmg.employee.crudemployee.impl;

import com.dihardmg.employee.crudemployee.dao.ClienteDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class ClienteDaoImplTest {

    @Resource
    private ClienteDao clienteDao;

    @Test
    public void crearCliente() {
        //clienteDao.crearCliente("5555","5555","5555","5555","5555");
         clienteDao.crearCliente("777","777","777","777","777");

         }
}
package com.dihardmg.employee.crudemployee.dao;

import com.dihardmg.employee.crudemployee.entity.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface StudentDao extends PagingAndSortingRepository<Student, String>{
    public Page<Student> findByUsernameContainingIgnoreCase(String username, Pageable pageable);
}

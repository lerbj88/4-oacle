package com.dihardmg.employee.crudemployee.dao.impl;

import com.dihardmg.employee.crudemployee.dao.ClienteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

@Repository
public class ClienteDaoImpl implements ClienteDao {

    @Autowired
    private EntityManager entityManager;

    @Override
    public void crearCliente(String id, String cliente, String tienda, String email, String telefono) {
        //"login" this is the name of your procedure
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery("sp_insertarcliente");

        //Declare the parameters in the same order
        query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(3, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(4, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(5, String.class, ParameterMode.IN);
        //query.registerStoredProcedureParameter(3, Integer.class, ParameterMode.OUT);
        //query.registerStoredProcedureParameter(4, String.class, ParameterMode.OUT);

        //Pass the parameter values
        query.setParameter(1, id);
        query.setParameter(2, cliente);
        query.setParameter(3, tienda);
        query.setParameter(4, email);
        query.setParameter(5, telefono);


        //Execute query
        query.execute();

        //Get output parameters
        //Integer outCode = (Integer) query.getOutputParameterValue(3);
        //String outMessage = (String) query.getOutputParameterValue(4);
    }
}

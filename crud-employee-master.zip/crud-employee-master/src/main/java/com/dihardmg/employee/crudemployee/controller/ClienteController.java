package com.dihardmg.employee.crudemployee.controller;

import com.dihardmg.employee.crudemployee.dao.ClienteDao;
import com.dihardmg.employee.crudemployee.forms.ClienteForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

@Controller
@RequestMapping("/cliente")
public class ClienteController {


    @Autowired
    private ClienteDao clienteDao;

    @GetMapping("/form")
    public String form(ModelMap model){
        ClienteForm clienteForm = new ClienteForm();
        model.addAttribute("cliente", clienteForm);
        return "cliente/form";
    }


    @PostMapping("/form")
    public String agregar(@ModelAttribute(value = "cliente") ClienteForm clienteForm, BindingResult errors, SessionStatus status) {
        if (errors.hasErrors()) {
            return "cliente/form";
        }

        clienteDao.crearCliente(clienteForm.getId(), clienteForm.getCliente(), clienteForm.getTienda(),clienteForm.getEmail(), clienteForm.getTelefono());
         status.setComplete();
        return "redirect:form";
    }

}
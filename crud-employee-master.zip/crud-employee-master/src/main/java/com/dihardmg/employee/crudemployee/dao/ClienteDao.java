package com.dihardmg.employee.crudemployee.dao;

public interface ClienteDao {

    void crearCliente(String id, String cliente, String tienda, String email, String telefono);
}
